https://github.com/Welsyntoffie/csgo-gsi-python-to-arduino/releases/tag/v1.0.0


Installer will check if python 3.7 is installed. (only tested with 3.7) if not then 3.7 will be installed. Installer will then check if Arduino IDE is installed. (any version) If not then 1.8 will be installed.

Installer will create the path in Environment Variables for python. Installer will then copy the files needed to their respective directories. Finally a shortcut will be added to your desktop that will launch the listener server.

Arduino files and needed libraries will be added to user/documents/Arduino and user/documents/libraries.
